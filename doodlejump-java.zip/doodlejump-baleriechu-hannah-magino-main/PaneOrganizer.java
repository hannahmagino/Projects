package doodlejump;


import javafx.event.ActionEvent;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;

/**
 * The PaneOrganizer class creates the different panes of the DoodleJump game and adds them to the root
 */
public class PaneOrganizer {
    private BorderPane root;

    /**
     * The constructor of PaneOrganizer
     */
    public PaneOrganizer() {
        this.root = new BorderPane();
        new DoodleJumpGame(this.root);
        this.setUpButtonPane();
    }

    /**
     * This method sets up the buttons, quit and restart, and adds them to the buttonPane
     */
    private void setUpButtons(HBox buttonPane) {
        Button quitButton = new Button("Quit");
        quitButton.setPrefSize(Constants.BUTTON_WIDTH, Constants.BUTTON_HEIGHT);
        quitButton.setOnAction((ActionEvent e) -> System.exit(0));
        quitButton.setFocusTraversable(false);

        Button restartButton = new Button("Restart");
        restartButton.setPrefSize(Constants.BUTTON_WIDTH, Constants.BUTTON_HEIGHT);
        restartButton.setOnAction((ActionEvent e) -> { //when the restart button is clicked, clear the root of the
            // original game and reset it with a new game and button pane
            this.root.getChildren().clear();
            new DoodleJumpGame(this.root);
            this.setUpButtonPane();
        });
        restartButton.setFocusTraversable(false);
        buttonPane.getChildren().addAll(quitButton, restartButton);
    }

    /**
     * The method sets up the buttons pane and adds it to the root
     */
    private void setUpButtonPane() {
        HBox buttonPane = new HBox();
        buttonPane.setAlignment(Pos.CENTER);
        buttonPane.setStyle(Constants.BUTTON_PANE_COLOR);
        buttonPane.setSpacing(Constants.BUTTON_PANE_SPACING);
        this.root.setBottom(buttonPane);
        this.setUpButtons(buttonPane);
    }

    /**
     * This getter returns the root
     */
    public BorderPane getRoot() {
        return this.root;
    }
}
