package doodlejump;

import javafx.scene.paint.Color;


/**
 * The ExtraBouncyPlatform class defines how an extra bouncy platform looks like, and how it
 * reacts when it collides with the doodle
 */
public class ExtraBouncyPlatform extends Platform{

    /**
     * The constructor of ExtraBouncyPlatform
     */
    public ExtraBouncyPlatform(double x, double y) {
        super(Color.YELLOW, x, y);
    }

    /**
     * this method is called when the doodle intersects with an extra bouncy platform, which causes the doodle
     * to rebound by the extra bouncy velocity
     */
    @Override
    public void collisionBehavior(Doodle doodle){
        doodle.setVelocity(Constants.BOUNCY_REBOUND_VELOCITY);
    }

}
