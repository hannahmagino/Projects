package doodlejump;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * This is the App class, which handles starting the application of the game
 */
public class App extends Application {

    /**
     * This method starts the program, by setting up the DoodleJump GUI by instantiating the Pane Organizer which
     * holds the different screens of the game, and setting the scene to the stage
     */
    @Override
    public void start(Stage stage) {

        // Instantiate top-level object, set up the scene, and show the stage here.
        PaneOrganizer organizer = new PaneOrganizer();
        Scene scene = new Scene(organizer.getRoot(), Constants.SCENE_WIDTH, Constants.SCENE_HEIGHT);
        stage.setScene(scene);
        stage.setTitle("Doodle Jump!");
        stage.show();
    }

    /*
     * Here is the mainline! No need to change this.
     */
    public static void main(String[] argv) {
        // launch is a static method inherited from Application.
        launch(argv);
    }
}
