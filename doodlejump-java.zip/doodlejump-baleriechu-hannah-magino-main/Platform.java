package doodlejump;

import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

/**
 * The Platform abstract class defines how a platform looks like and operates in the game
 */
public abstract class Platform {

    private Rectangle platform;

    /**
     * The constructor for Platform
     */
    public Platform(Color color, double x, double y) {
        this.platform = new Rectangle(x, y, Constants.PLATFORM_WIDTH, Constants.PLATFORM_HEIGHT);
        this.platform.setFill(color);
    }

    /**
     * This getter returns the y position of the platform
     */
    public double getY() {
        return this.platform.getY();
    }

    /**
     * This getter returns the x position of the platform
     */
    public double getX() {
        return this.platform.getX();
    }

    /**
     * This setter sets the x position of the platform to the new x position
     */
    public void setX(double newX) {
        this.platform.setX(newX);
    }

    /**
     * This method returns the platform shape (rectangle)
     */
    public Rectangle getPlatform(){
        return this.platform;
    }

    /**
     * This method describes how each platform reacts when it intersects with the doodle
     */
    public void collisionBehavior(Doodle doodle){
        doodle.setVelocity(Constants.REBOUND_VELOCITY);

    }

    /**
     * This method describe how each platform will move, with the default being they don't move
     */
    public void move(){

    };
}
