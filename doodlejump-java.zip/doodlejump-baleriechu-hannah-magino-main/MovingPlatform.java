package doodlejump;

import javafx.scene.paint.Color;

/**
 * The MovingPlatform class defines how a moving platform looks like, and how it
 * reacts when it collides with the doodle
 */
public class MovingPlatform extends Platform {
    private int direction; //-1 represents left and 1 represents right

    /**
     * This is the MovingPlatform constructor
     */
    public MovingPlatform(double x, double y) {
        super(Color.PINK, x, y);
        this.direction = 1;
    }

    /**
     * this method moves the moving platform both to the right and left throughout the game
     */
    @Override
    public void move() {
        //if the platform has reached the left or right side of the screen, change to the opposite direction
        if (this.getX() == 0 || this.getX() == Constants.SCENE_WIDTH - Constants.PLATFORM_WIDTH) {
                this.direction = this.direction * -1;
            }
            this.setX(getX() + this.direction);
    }
}
