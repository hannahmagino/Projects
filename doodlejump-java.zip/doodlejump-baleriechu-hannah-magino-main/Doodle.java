package doodlejump;

import javafx.scene.layout.Pane;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;

/**
 * This is the Doodle class, which creates the different parts of the doodle: body, left eye, and right eye. It also
 * defines how the doodle will move left and right, and up and down based off the velocity
 */
public class Doodle {
    private Rectangle body;
    private Circle leftEye;
    private Circle rightEye;
    private double currVelocity;
    private double currPosition;

    /**
     * The constructor of Doodle
     */
    public Doodle(Pane doodlePane) {
        this.makeDoodle(doodlePane);
        this.currVelocity = 0;
        this.currPosition= Constants.DOODLE_Y;
    }

    /**
     * This method defines the different body parts of the doodle and adds it to the doodlePane
     */
    private void makeDoodle(Pane doodlePane) {
        this.body = new Rectangle(Constants.DOODLE_X, Constants.DOODLE_Y,
                Constants.DOODLE_WIDTH, Constants.DOODLE_HEIGHT);
        this.body.setFill(Constants.DOODLE_COLOR);
        this.leftEye = new Circle(Constants.LEFT_EYE_X, Constants.EYE_Y, Constants.EYE_RADIUS);
        this.rightEye = new Circle(Constants.RIGHT_EYE_X, Constants.EYE_Y, Constants.EYE_RADIUS);
        doodlePane.getChildren().addAll(this.body, this.leftEye, this.rightEye);
    }

    /**
     * This method defines how much the doodle will move left if the left arrow key is pressed by the user and
     * how to wrap around once it reaches the left boundary of the screen
     */
    public void moveLeft() {
        //if the body of the doodle has reached the left boundary of the screen, reset doodle to right boundary
        if(this.body.getX() < 0 ) {
            this.setXPosition(Constants.SCENE_WIDTH);
        }else { //if not at the edge of screen, move the doodle to the left by the doodle offset constant
            this.setXPosition(this.body.getX() - Constants.DOODLE_OFFSET_X);
        }
    }

    /**
     * This method defines how much the doodle will move right if the right arrow key is pressed by the user and
     * how to wrap around once it reaches the right boundary of the screen
     */
    public void moveRight() {
        //if the doodle's body has reached the right boundary of the screen, reset doodle to the left boundary
        if(this.body.getX() + this.body.getWidth() > Constants.SCENE_WIDTH) {
            this.setXPosition(0);
        } else { //if not at the edge move the body by the doodle offset constant
            this.setXPosition(this.body.getX() + Constants.DOODLE_OFFSET_X);
        }
    }

    /**
     * This method sets the x position of the body, left eye, and right eye of the doodle
     */
    private void setXPosition(double newPosition){
        this.body.setX(newPosition);
        this.leftEye.setCenterX(newPosition + (Constants.EYE_X));
        this.rightEye.setCenterX(newPosition + Constants.EYE_X + Constants.EYE_OFFSET_X);
    }

    /**
     * This getter returns the current velocity of the doodle so the doodleMover can update the doodles position and
     * velocity. It can also be used to check if the doodle is moving up or down
     */
    public double getCurrVelocity() {
        return this.currVelocity;
    }

    /**
     * This method sets the new velocity of the doodle so the doodleMover can update it based off gravity
     */
    public void setVelocity(double newVelocity) {
        this.currVelocity = newVelocity;
    }

    /**
     * This method sets the Y position of the doodle's body and eyes and resets the current position to the new y
     * position
     */
    public void setYPosition(double newPosition) {
        this.currPosition = newPosition;
        this.body.setY(this.currPosition);
        this.leftEye.setCenterY(this.currPosition + Constants.EYE_OFFSET_Y);
        this.rightEye.setCenterY(this.currPosition + Constants.EYE_OFFSET_Y);
    }

    /**
     * This method returns the doodle's y position by returning the body's (rectangle) y position
     */
    public double getDoodleY() {
        return this.body.getY();
    }

    /**
     * This method returns the shape of the doodle, which is a rectangle, so it can be checked for collisions
     */
    public Rectangle getDoodle() {
        return this.body;
    }
}
