package doodlejump;

import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import java.util.ArrayList;

/**
 * The DisappearingPlatform class defines how a disappearing platform looks like, and how it
 * reacts when it collides with the doodle
 */
public class DisappearingPlatform extends Platform {
    private ArrayList<Platform> platforms;
    private Pane doodlePane;

    /**
     * The constructor of Disappearing Platform
     */
    public DisappearingPlatform(double x, double y, ArrayList<Platform> platforms, Pane doodlePane ){
        super(Color.PURPLE, x, y);
        this.platforms = platforms;
        this.doodlePane = doodlePane;
    }

    /**
     * collisionBehavior, which is called when the doodle intersects with a disappearing platform, will rebound the
     * doodle and remove the platform both logically and graphically, so it doesn't show up on the screen anymore
     */
    @Override
    public void collisionBehavior(Doodle doodle) {
        super.collisionBehavior(doodle);
        this.doodlePane.getChildren().remove(this.getPlatform());
        this.platforms.remove(this);
    }
}
