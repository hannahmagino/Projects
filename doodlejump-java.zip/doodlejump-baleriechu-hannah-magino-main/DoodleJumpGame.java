package doodlejump;

import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;

import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.util.Duration;

import java.util.ArrayList;

/**
 * This class sets up the logic of the DoodleJump Game, including setting up the platforms, and updating the game based
 * off the movement of the doodle and its interactions with features of the game (platforms)
 */
public class DoodleJumpGame {
    private Pane doodlePane;
    private ArrayList<Platform> platforms;
    private Platform topmostPlatform;
    private Label scoreLabel;
    private int score;
    private boolean isPaused;
    private boolean gameOver;

    /**
     * The Constructor of DoodleJumpGame
     */
    public DoodleJumpGame(BorderPane root) {
        this.isPaused = false;
        this.gameOver = false;
        this.doodlePane = new Pane();
        root.setCenter(this.doodlePane);
        this.setUpScoreLabel();
        this.createTopPlatform();
        this.updateGame(new DoodleMover(this.doodlePane));
    }

    /**
     * This method creates the platform arraylist and adds the first top-most platform to the list and the pane
     */
    private void createTopPlatform() {
        this.platforms = new ArrayList<>();
        this.topmostPlatform = new StandardPlatform(Constants.DOODLE_X, Constants.PLATFORM_Y);
        this.platforms.add(this.topmostPlatform);
        this.doodlePane.getChildren().add(this.topmostPlatform.getPlatform());
    }

    /**
     * This method sets up the score label
     */
    private void setUpScoreLabel() {
        this.score = 0;
        this.scoreLabel = new Label();
        this.scoreLabel.setText("Score: " + this.score);
        this.doodlePane.getChildren().add(this.scoreLabel);
    }

    /**
     * This method sets up the pause button, and calls the pauseGame() method if the button is pressed
     */
    private void setUpPause(Timeline gameTimeline, DoodleMover doodle) {
        Button pauseButton = new Button("Pause");
        pauseButton.setPrefSize(Constants.BUTTON_WIDTH, Constants.BUTTON_HEIGHT);
        pauseButton.setLayoutX(Constants.SCENE_WIDTH - Constants.BUTTON_WIDTH);
        pauseButton.setOnAction((ActionEvent e) -> this.pauseGame(gameTimeline, doodle));
        this.doodlePane.getChildren().add(pauseButton);
        pauseButton.setFocusTraversable(false);
     }

    /**
     * When called, this method updates the isPaused boolean and pauses/plays the gameTimeline based on the current
     * status
     */
    private void pauseGame(Timeline gameTimeline, DoodleMover doodle) {
        if(!this.gameOver) { //checks to make sure game isn't already over
            if (!this.isPaused) { //checks to see if game isn't paused
                this.isPaused = true;
                doodle.updateStatus(this.isPaused);
                gameTimeline.pause();

            } else {
                this.isPaused = false;
                doodle.updateStatus(this.isPaused);
                gameTimeline.play();
            }
        }
    }

    /**
     * this method creates the key frame that updates the components of the game including: generating/removing
     * platforms, updating the doodles position, checking for collisions, scrolling, and checking if the game is over
     */
    private void updateGame(DoodleMover doodle) {
        Timeline gameTimeline = new Timeline();
        this.setUpPause(gameTimeline, doodle);
        KeyFrame kf = new KeyFrame(Duration.seconds(Constants.DURATION), (ActionEvent e) -> {
            this.generatePlatform();
            doodle.updateMovement();
            doodle.checkCollision(this.platforms);
            this.scroll(doodle);
            this.checkPlatform();
            this.checkGameStatus(doodle, gameTimeline);
        });
        gameTimeline.getKeyFrames().add(kf);
        gameTimeline.setCycleCount(Animation.INDEFINITE);
        gameTimeline.play();
    }

    /**
     * this method checks if the doodle has fallen off the screen. if it has, it calls the endGame method
     */
    private void checkGameStatus(DoodleMover doodle, Timeline gameTimeline) {
        if(doodle.getDoodle().getDoodleY() > Constants.SCENE_HEIGHT - Constants.BUTTON_HEIGHT) {
            this.endGame(gameTimeline);
        }
    }

    /**
     * this method sets up the end of the game by setting the gameOver status to true, making the gameOverLabel and
     * stopping the game timeline when called
     */
    private void endGame(Timeline gameTimeline) {
        this.gameOver = true;
        this.makeGameOverLabel();
        gameTimeline.stop();
    }

    /**
     * this method creates the gameOver label and adds it to the doodlePane
     */
    private void makeGameOverLabel() {
        Pane labelPane = new Pane();
        Label gameOverLabel = new Label("Game Over");
        gameOverLabel.setFont(new Font("Elephant", Constants.FONT_SIZE));
        gameOverLabel.setTextFill(Color.MAROON);
        labelPane.getChildren().add(gameOverLabel);
        this.doodlePane.getChildren().add(labelPane);
        labelPane.setLayoutX(Constants.LABEL_PANE_X);
        labelPane.setLayoutY((Constants.SCENE_HEIGHT - Constants.BUTTON_HEIGHT) / Constants.HALF);
    }

    /**
     * this method sets up the scroll capabilities of the game based on if the doodle moves past the midpoint of
     * the screen
     */
    private void scroll(DoodleMover doodle) {
        if (doodle.getDoodle().getDoodleY() < Constants.SCENE_HEIGHT / Constants.HALF) {
            double difference = (Constants.SCENE_HEIGHT / Constants.HALF) - doodle.getDoodle().getDoodleY();
            for (Platform platform : this.platforms) {
                //for each platform on the list move it down by the difference
                platform.getPlatform().setY(platform.getPlatform().getY() + difference);
            }
            doodle.getDoodle().setYPosition(Constants.SCENE_HEIGHT / Constants.HALF);
            this.scoreLabel.setText("Score: " + this.score++);
        }
    }

    /**
     * this method checks if the platforms have moved off the screen, if so it removes the platform both logically
     * and graphically
     */
    private void checkPlatform() {
        for (int i = 0; i < this.platforms.size(); i++) {
            Platform currPlatform = this.platforms.get(i);
            currPlatform.move();
            //checks if platform is still visible on the screen and removes it if not
            if (currPlatform.getPlatform().getY() > Constants.SCENE_HEIGHT - Constants.BUTTON_HEIGHT) {
                this.doodlePane.getChildren().remove(currPlatform.getPlatform());
                this.platforms.remove(currPlatform);
            }
        }
    }

    /**
     * this method semi-randomly generates the platforms that show up on the screen based off the x and y bounds
     */
    private void generatePlatform() {
        while(this.topmostPlatform.getY() > 0){ //checks if the topmost platform isn't above the scene
            //low and high x bounds
            double lowX = Math.max(0, this.topmostPlatform.getX() - Constants.PLATFORM_OFFSET_X);
            double highX = Math.min(Constants.SCENE_WIDTH - Constants.PLATFORM_WIDTH,
                    this.topmostPlatform.getX() + Constants.PLATFORM_OFFSET_X);
            double randomX = lowX + (int)((highX - lowX) * Math.random()); //random bound between lowX and highX

            //min and max y bounds
            double lowY = this.topmostPlatform.getY() - Constants.MIN_OFFSET_Y;
            double highY = this.topmostPlatform.getY() - Constants.MAX_OFFSET_Y;
            double randomY = lowY + (int)((highY - lowY) * Math.random()); //random bound between lowY and highY

            this.topmostPlatform = this.randomizePlatform(randomX, randomY);
            this.platforms.add(this.topmostPlatform);
            this.doodlePane.getChildren().add(this.topmostPlatform.getPlatform());
        }
    }

    /**
     * this method randomly generates the type of platform that will be displayed and returns it
     */
    private Platform randomizePlatform(double x, double y) {
        int randInt = (int) (Math.random() * Constants.NUM_PLATFORM_TYPES); //random int from 0 to # of platforms
        Platform newPlatform = null;
        switch (randInt) { // based off the random number a unique type of platform is generated
            case 1:
                newPlatform = new StandardPlatform(x, y);
                break;
            case 2:
                newPlatform = new MovingPlatform(x, y);
                break;
            case 3:
                newPlatform = new DisappearingPlatform(x, y, this.platforms, this.doodlePane);
                break;
            case 4:
                newPlatform = new ChameleonPlatform(x, y);
                break;
            default:
                newPlatform = new ExtraBouncyPlatform(x, y);
                break;
        }
        return newPlatform;
    }
}
