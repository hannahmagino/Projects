package doodlejump;

import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.Pane;

import java.util.ArrayList;

/**
 * This class controls the movement of the doodle by creating the timeline it follows. It references the doodle, the
 * pane it is held in, and the isPaused boolean
 */
public class DoodleMover {
    private Doodle doodle;
    private Pane doodlePane;
    private boolean isPaused;

    /**
     * The constructor of DoodleMover
     */
    public DoodleMover(Pane doodlePane){
        this.doodle = new Doodle(doodlePane);
        this.doodlePane = doodlePane;
        this.doodlePane.setFocusTraversable(true);
        this.updateLocation();
        this.updateStatus(false);
    }

    /**
     * This method loops through all the platforms on the screen, and checks if the doodle is intersecting with any of
     * them
     */
    public void checkCollision(ArrayList<Platform> platforms) {
        for(int i = 0; i < platforms.size(); i++){
            Platform currPlatform = platforms.get(i);
            //if the doodle is moving downward and intersects with the platform, then run the collision behavior method
            if (this.doodle.getCurrVelocity() > 0 && this.doodle.getDoodle().intersects(currPlatform.getX(),
                    currPlatform.getY(), Constants.PLATFORM_WIDTH, Constants.PLATFORM_HEIGHT)) {
                currPlatform.collisionBehavior(this.doodle);
            }
        }
    }

    /**
     * This method creates the key event used to update the doodles location by calling the handleKeyPress method
     */
    private void updateLocation() {
        this.doodlePane.setOnKeyPressed((KeyEvent e) -> this.handleKeyPress(e));
    }

    /**
     * This method checks if the left or right key is pressed, then calls the moveLeft() or moveRight() method
     * according to the key pressed
     */
    private void handleKeyPress(KeyEvent e) {
        //checks if the game isn't paused, and the doodle is on the screen
        if (!this.isPaused && this.doodle.getDoodleY() < Constants.SCENE_HEIGHT - Constants.BUTTON_HEIGHT ) {
            KeyCode keyPressed = e.getCode();
            switch (keyPressed) { //if key is left, call moveLeft(), if key is right, call moveRight()
                case LEFT:
                    this.doodle.moveLeft();
                    break;
                case RIGHT:
                    this.doodle.moveRight();
                    break;
                default:
                    break;
            }
            e.consume();
        }
    }

    /**
     * This method updates the velocity and the y-position of the doodle based on the gravity constant
     */
    public void updateMovement() {
        this.doodle.setVelocity(this.doodle.getCurrVelocity() + Constants.GRAVITY * Constants.DURATION);
        this.doodle.setYPosition(this.doodle.getDoodleY() + this.doodle.getCurrVelocity() * Constants.DURATION);
    }

    /**
     * This getter returns the doodle
     */
    public Doodle getDoodle() {
        return this.doodle;
    }

    /**
     * This method updates the status of the game (paused or not paused)
     */
    public void updateStatus(boolean isPaused) {
        this.isPaused = isPaused;
    }
}
