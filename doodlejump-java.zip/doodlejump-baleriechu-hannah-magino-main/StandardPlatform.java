package doodlejump;

import javafx.scene.paint.Color;

/**
 * The StandardPlatform class defines how a standard platform looks like, and how it
 * reacts when it collides with the doodle
 */
public class StandardPlatform extends Platform {

    /**
     * The constructor of StandardPlatform
     */
    public StandardPlatform(double x, double y) {
        super(Color.BLACK, x, y);
    }

}
