package doodlejump;

import javafx.scene.paint.Color;

/**
 * The ChameleonPlatform class defines how a chameleon platform looks like, and how it
 * reacts when it collides with the doodle
 */
public class ChameleonPlatform extends Platform {

    /**
     * The constructor of ChameleonPlatform
     */
    public ChameleonPlatform(double x, double y) {

        super(Color.rgb(Constants.RED_VALUE, Constants.GREEN_VALUE, Constants.BLUE_VALUE), x, y);
    }

    /**
     * this method is called when the doodle intersects with a chameleon platform, which causes the doodle
     * to rebound by the rebound velocity and the opacity of the platform to be randomized
     */
    @Override
    public void collisionBehavior(Doodle doodle) {
        super.collisionBehavior(doodle);
        double opacity = Math.random();
        this.getPlatform().setFill(Color.rgb(Constants.RED_VALUE, Constants.GREEN_VALUE,
                Constants.BLUE_VALUE, opacity));
    }

}
